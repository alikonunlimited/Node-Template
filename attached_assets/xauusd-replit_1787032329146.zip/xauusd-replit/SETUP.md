# XAU/USD AI Trader — Replit Setup Guide
## Live in ~10 minutes

---

## STEP 1 — Create the Replit

1. Go to **replit.com** → Sign in → **Create Repl**
2. Choose **Node.js** template
3. Name it: `xauusd-trader`
4. Click **Create Repl**

---

## STEP 2 — Upload the Files

In the Replit file panel (left sidebar):

Upload or create each file exactly as named:
```
main.js          ← the trading engine
engine.js        ← AI indicator logic
sheets.js        ← Google Sheets logger
package.json     ← dependencies
.replit          ← Replit config
replit.nix       ← Node version
public/
  index.html     ← live dashboard
```

**Easiest method:** Click the three dots (⋯) next to Files → **Upload folder** → upload the entire `xauusd-replit` folder.

---

## STEP 3 — Google Sheets Setup

1. Go to **sheets.google.com** → New spreadsheet
2. Name it: `XAU/USD AI Trader`
3. At the bottom, create two tabs:
   - Rename `Sheet1` → `TradeLog`
   - Click `+` → rename → `DailySummary`
4. Copy the **Sheet ID** from the URL:
   `docs.google.com/spreadsheets/d/`**COPY_THIS_PART**`/edit`

---

## STEP 4 — Google Service Account

1. Go to **console.cloud.google.com**
2. Create a new project (name anything)
3. Search "Google Sheets API" → **Enable**
4. Go to **IAM & Admin → Service Accounts → Create Service Account**
   - Name: `xauusd-trader` → Create and Continue → Done
5. Click your service account → **Keys tab** → Add Key → **JSON**
   - A `.json` file downloads to your computer
6. Open your Google Sheet → **Share**
   - Paste the `client_email` value from the JSON
   - Set to **Editor** → Share

---

## STEP 5 — Add Secrets in Replit

In Replit, click the **🔒 Secrets** tab (padlock icon, left sidebar):

Add each secret:

| Key | Value |
|-----|-------|
| `GOOGLE_SHEET_ID` | The ID from Step 3 |
| `GOOGLE_SERVICE_ACCOUNT_JSON` | Paste the **entire contents** of your downloaded .json file |
| `STARTING_BALANCE` | `10000` |
| `ANALYSIS_INTERVAL_SECONDS` | `30` |

> **Tip:** Open the .json file in a text editor, select all, copy, paste into the secret value.

---

## STEP 6 — Run It

1. Click the green **▶ Run** button
2. You'll see the console log:
   ```
   ╔══════════════════════════════════════╗
   ║  XAU/USD AI Trader — Replit Edition  ║
   ╚══════════════════════════════════════╝
   [Server] Running on port 3000
   [Sheets] Headers ensured
   [INFO] Started | $4351.xx from goldprice.org
   ```
3. Replit shows a **preview window** at the top right — that's your live dashboard
4. Click **Open in new tab** → copy that URL → bookmark it on your phone

---

## STEP 7 — Keep It Running 24/7 (Important!)

Replit free tier sleeps after ~1 hour of no traffic.

**The app self-pings every 4 minutes automatically** — but only works if it knows its own URL.

Add one more secret:
| Key | Value |
|-----|-------|
| `PUBLIC_URL` | Your Replit URL (e.g. `https://xauusd-trader.yourname.repl.co`) |

This makes the keep-alive pinger work and prevents sleeping.

**Optional but better — UptimeRobot (free):**
1. Go to **uptimerobot.com** → free account
2. Add New Monitor → HTTP(s)
3. URL: your Replit URL + `/health`
4. Interval: every 5 minutes
5. This pings from outside — 100% reliable keep-alive

---

## What Runs Automatically

| Frequency | Action |
|-----------|--------|
| Every 5 sec | Price tick + TP/SL check |
| Every 30 sec | Full AI analysis + trade decision |
| On close | Trade row → `TradeLog` sheet instantly |
| Midnight UTC | Summary row → `DailySummary` sheet |

---

## Checking Results on Your Phone

- Open Google Sheets app → your `XAU/USD AI Trader` sheet
- **TradeLog** — every trade: entry, exit, P&L, reason
- **DailySummary** — daily win rate, gross P&L, running balance

---

## Your Dashboard URL

Open this anytime from any device:
`https://xauusd-trader.YOUR-REPLIT-USERNAME.repl.co`

No login needed. Updates live every 5 seconds.
